import os
import numpy as np 

fx = np.array([11, 23, 5, 15, 28, 17, 45, 41])

def fft(fx):
	fx = np.asarray(fx, dtype=float)
	N = fx.shape[0]
	n= np.arange(N)
	n_even = n[::2]
	n_odd = n[1::2]
	if N>1:
		X_e = np.array([fx[n] for n in n_even])
		X_o = np.array([fx[n] for n in n_odd])
		X_e = fft(X_e)
		X_o = fft(X_o)
		factor = np.exp(-2j * np.pi * np.arange(N) / N)
		return np.concatenate([X_e + factor[:N / 2] * X_o,
           		X_e + factor[N / 2:] * X_o])


fk = fft(fx)
print(fk)